﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQtoSQL
{
    class MainClass
    {

        static DBDataContextDataContext db = new DBDataContextDataContext();
        static void InsertTblMyStudent(TblMyStudent std)
        {
            db.TblMyStudents.InsertOnSubmit(std);

        }
        static List<TblMyStudent> SelectTblMyStudent()
        {
            return (from emp in db.TblMyStudents select emp).ToList<TblMyStudent>();

        }
        static void Main()
        {
            foreach (var s in SelectTblMyStudent())
            {
                Console.WriteLine("StuId={0}", s.StuId);
                Console.WriteLine("StuName={0}", s.StuName);
                Console.WriteLine("StuSubject={0}", s.StuSubject);


            }
            TblMyStudent std1 = new TblMyStudent();
            std1.StuId = 1;
            std1.StuName = "Venkat";
            std1.StuSubject = "physics";
            InsertTblMyStudent(std1);

            db.SubmitChanges();
            Console.ReadKey();
        }
    }
}


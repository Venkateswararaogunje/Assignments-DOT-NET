﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace functions
{
    class bank
    {
        private double bal = 1000;
        public double balance
        {
            get
            {
                return balance;
            }
            set
            {
                balance = value;
            }
        }
    }
    class functions
    {
        bank i = new bank();
        string name;
        int account;
        double withdraw, deposit, totalbalance;
        public void fun1()
        {
            Console.WriteLine("Enter name of the depositor:");
            name = Console.ReadLine();
            Console.WriteLine("Enter Account Number:");
            account = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Deposit Amount:");
            deposit = Convert.ToDouble(Console.ReadLine());
            totalbalance = i.balance + deposit;
            Console.WriteLine("-----------------------/n");
            Console.WriteLine("Name of the depositor:" + name);
            Console.WriteLine("Account Number:" + account);
            Console.WriteLine("Total Balance Amount in the Account:" + totalbalance);
        }
        public void fun2()
        {
            Console.WriteLine("Enter Account Name:");
            name = Console.ReadLine();
            Console.WriteLine("Enter Account Number:");
            account = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Withdraw Amount:");
            withdraw = Convert.ToDouble(Console.ReadLine());
            if (withdraw <= i.balance)
            {
                totalbalance = i.balance - withdraw;
                Console.WriteLine("-------------------/n");
                Console.WriteLine("Account Name:" + name);
                Console.WriteLine("Account Number:" + account);
                Console.WriteLine("After withdraw amount balance is:" + totalbalance);
            }
            else
            {
                Console.WriteLine("/n/nWithdraw amount does not exist your account:");
            }




        }
    }
}
class Mainclass
{
    static void Main()
    {
        char again;
        do
        {
            function i = new function();
            int num;
            Console.WriteLine("Please select any Function:");
            Console.WriteLine("\n press1 for deposit an amount:\n press2 for withdraw an amount:");
            num = Convert.ToInt32(Console.ReadLine());
            switch (num)
            {
                case 1:
                    i.fun1();
                    break;
                case 2:
                    i.fun2();
                    break;
                default:
                    Console.WriteLine("Invalid selection!!");
                    break;
            }
            Console.WriteLine("/n Do you want to continue this (y/n)");
            again = Convert.ToChar(Console.ReadLine());
        }
        while (again == 'y');
        Console.ReadKey();
    }
}


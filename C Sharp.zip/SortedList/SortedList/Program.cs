﻿using System;
using System.Collections;

namespace SortedListExample
{
    class MainClass
    {
        static void Main()
        {
            SortedList s1 = new SortedList();
            s1.Add("A1", "Venkat");
            s1.Add("A2", "Rao");
            s1.Add("A5", "Triandh");
            s1.Add("A4", "Dhiraj");
            s1.Add("A6", "prakash");
            s1.Add("A3", "Chaitamya");
            ICollection c = s1.Values;
            foreach (object o in s1.Values)
            {
                Console.WriteLine(o);
            }
            Console.WriteLine("--------------");
            foreach (string i in s1.Keys)
            {
                Console.WriteLine(s1[i]);
            }
            Console.WriteLine("\n{0} is at Index 3",s1.GetByIndex(3));
        }
    }
}
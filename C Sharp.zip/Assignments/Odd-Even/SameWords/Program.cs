﻿using System;

namespace SameWords
{
    class MainClass
    {
        static void Main()
        {
            Console.WriteLine("Enter Word 1 : ");
            string w1 = Console.ReadLine();
            Console.WriteLine("Enter Word 2 : ");
            string w2 = Console.ReadLine();
            if(w1 == w2)
            {
                Console.WriteLine("Print the Two words are same");
            }
            else
            {
                Console.WriteLine("Print the two words are not same");
            }
        }

}
}


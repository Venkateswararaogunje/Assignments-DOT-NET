﻿using CrudOperations_MVCcore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CrudOperations_MVCcore.Controllers
{
    public class SellerController : Controller
    {
       

        public ActionResult Create()

        {

            return View();

        }
        [HttpGet]
        public ActionResult Read()
        {
            using (var context = new demoCRUDEntities())
            {
                var data = context.Seller.ToList();
                return View(data);
            }

        }

        [HttpPost]

        public ActionResult Create(Seller sel)
        {
            if (ModelState.IsValid)
            {
                db.Seller.Add(sel);
                db.SaveChanges();
                return RedirectToAction("Index");

            }
            return View(sel);
        }
        [HttpPut]
        public ActionResult Update(Seller sel)

        {

            if (ModelState.IsValid)

            {

                db.Entry(sel).State = EntityState.Modified;

                db.SaveChanges();

                return RedirectToAction("Index");

            }

            return View(sel);

        }
        [HttpDelete]
        public ActionResult Delete(string id = null)

        {
            

            Seller sel = db.Seller.Find(id);

            db.Seller.Remove(sel);

            db.SaveChanges(); 
            
            return RedirectToAction("Index");

        }

    }
}

﻿using CrudOperations_CoreWebAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace CrudOperations_CoreWebAPI.DA_L
{
    public class SellerContext : DbContext
    {
        public SellerContext(DbContextOptions<SellerContext> options)
        : base(options)
        {

        }

        public DbSet<Seller> Sellers { get; set; }
    }
}

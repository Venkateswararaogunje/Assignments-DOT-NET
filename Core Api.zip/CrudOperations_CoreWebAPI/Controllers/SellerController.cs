﻿using CrudOperations_CoreWebAPI.DA_L;
using CrudOperations_CoreWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections;

namespace CrudOperations_CoreWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SellerController : ControllerBase
    {
        private readonly SellerContext _context;

        public SellerController(SellerContext context)
        {
            _context = context;

            if (_context.Sellers.Count() == 0)
            {
                _context.Sellers.Add(new Seller
                {
                    CompanyName = "Siri Constructions",
                    ContactName = "Varma",
                    City = "Mumbai",
                    Country = "India",
                    Phone = "9999999999",

                });

                _context.Sellers.Add(new Seller
                {
                    CompanyName = "Vivek Constructions",
                    ContactName = "Prabhu",
                    City = "New York",
                    Country = "USA",
                    Phone = "8888888888",

                });
                _context.SaveChanges();
            }
        }

        [HttpGet]
        public IEnumerable GetAll()
        {
            return _context.Sellers.ToList();
        }
        [HttpGet("{id}", Name = "GetSeller")]
        public IActionResult GetById(long id)
        {
            var item = _context.Sellers.FirstOrDefault(t => t.Id == id);
            if (item == null)
            {
                return NotFound();
            }
            return new ObjectResult(item);
        }
        [HttpPost]
        public IActionResult Create([FromBody] Seller item)
        {
            if (item == null)
            {
                return BadRequest();
            }

            _context.Sellers.Add(item);
            _context.SaveChanges();

            return CreatedAtRoute("GetById", new { id = item.Id }, item);
        }
        [HttpPut("{id}")]
        public IActionResult Update(long id, [FromBody] Seller item)
        {
            if (item == null || item.Id != id)
            {
                return BadRequest();
            }

            var seller = _context.Sellers.FirstOrDefault(t => t.Id == id);
            if (seller == null)
            {
                return NotFound();
            }

            seller.CompanyName = item.CompanyName;
            seller.ContactName = item.ContactName;
            seller.Country = item.Country;
            seller.City = item.City;

            _context.Sellers.Update(seller);
            _context.SaveChanges();
            return new NoContentResult();
        }
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            var seller = _context.Sellers.FirstOrDefault(t => t.Id == id);
            if (seller == null)
            {
                return NotFound();
            }

            _context.Sellers.Remove(seller);
            _context.SaveChanges();
            return new NoContentResult();
        }
    }
}

﻿using System;



class report
{

    static void Main(string[] args)
    {

        int m1, m2, m3, total;
        float Average;
        string name;


        Console.WriteLine("Enter Student Name :");
        name = Console.ReadLine();
        Console.WriteLine("Enter C# Marks : ");
        m1 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter Asp.Net Marks : ");
        m2 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter Sql_Server Marks :");
        m3 = Convert.ToInt32(Console.ReadLine());

        total = m1 + m2 + m3;
        Average = total / 3.0f;
        Console.WriteLine("Final result of {0} is:", name);
        Console.WriteLine("------------------------------");
        Console.WriteLine("Total Marks : " + total);
        Console.WriteLine("Percentage : " + Average);

        if (Average < 50)
        {
            Console.WriteLine("Sorry! fail");
        }
        else
        {
            Console.WriteLine(" Hurry! pass");

        }

    }
}
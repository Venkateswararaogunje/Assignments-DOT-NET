﻿using System;
namespace Welcome
{
    class MainClass
    {
        static void Main()
        {
            Console.WriteLine("Enter the name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Hi! {0}",name);
            Console.WriteLine("Welcome to the world of C#");
        }
    }
}

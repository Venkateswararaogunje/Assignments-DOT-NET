﻿using System;
namespace ReverseaWord
{
    class MainClass
    {
        static void Main()
        {
            Console.WriteLine("Enter the Word :");
            string s1 = Console.ReadLine();
            s1.Reverse();
            Console.WriteLine("After reversing the Word : " + s1);
        }
    }
}